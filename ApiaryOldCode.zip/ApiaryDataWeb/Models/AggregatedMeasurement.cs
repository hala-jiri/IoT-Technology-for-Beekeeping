﻿namespace ApiaryDataWeb.Models
{
    public class AggregatedMeasurement
    {
        public int HiveNumber { get; set; }
        public DateTime MeasurementDate { get; set; }
        public double AvgWeight { get; set; }
        public double AvgTemperature { get; set; }
    }
}
