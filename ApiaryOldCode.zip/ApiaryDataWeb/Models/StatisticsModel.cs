﻿namespace ApiaryDataWeb.Models
{
    public class StatisticsModel
    {
        public int NumberOfHives { get; set; }
        public int NumberOfApiaries { get; set; }

    }
}
