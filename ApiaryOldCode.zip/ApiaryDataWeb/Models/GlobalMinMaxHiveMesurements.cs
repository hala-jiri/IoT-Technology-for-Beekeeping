﻿using ApiaryDataCollector.Models;

namespace ApiaryDataWeb.Models
{
    public class GlobalMinMaxHiveMesurements
    {
        public double MinWeight { get; set; } = 0;
        public HiveMeasurement MinWeightMeasurement { get; set; }
        public double MaxWeight { get; set; } = 0;
        public HiveMeasurement MaxWeightMeasurement { get; set; }

        public double MinTemperature { get; set; } = 0;
        public HiveMeasurement MinTemperatureMeasurement { get; set; }
        public double MaxTemperature { get; set; } = 0;
        public HiveMeasurement MaxTemperatureMeasurement { get; set; }

        public int MinHumidity { get; set; } = 0;
        public HiveMeasurement MinHumidityMeasurement { get; set; }
        public int MaxHumidity { get; set; } = 0;
        public HiveMeasurement MaxHumidityMeasurement { get; set; }

    }
}
