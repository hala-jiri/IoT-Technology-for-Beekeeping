﻿using ApiaryDataWeb.Models;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace ApiaryDataWeb.Controllers
{
    public class ChartController : Controller
    {
        //https://www.chartjs.org/docs/latest/axes/cartesian/time.html
        /*
         *
         data: [{
                    x: "2016-12-25",
                    y: 3
                  }, {
                    x: "2016-12-28",
                    y: 10
                  }, {
                    x: "2016-12-29",
                    y: 5
                  }, {
                    x: "2016-12-30",
                    y: 2
                  }, {
                    x: "2017-01-03",
                    y: 20
                  }, {
                    x: "2017-01-05",
                    y: 30
                  }, {
                    x: "2017-01-08",
                    y: 45
            }], 
         */
        public IActionResult TimeSeriesChart()
        {
            ViewBag.ChartData = JsonConvert.SerializeObject(new
            {
                datasets = new[]
                {
                    new
                    {
                        label = "Teplota",
                        borderColor = "rgba(255, 99, 132, 1)", // Červená barva
                        data = new[]
                        {
                            new { koko = "2025-01-01T10:00:00Z", value = 10 },
                            new { koko = "2025-01-01T11:00:00Z", value = 8 },
                            new { koko = "2025-01-01T12:00:00Z", value = 20 },
                            new { koko = "2025-01-01T13:00:00Z", value = 17 },
                            new { koko = "2025-01-01T14:00:00Z", value = 11 },
                            new { koko = "2025-01-01T15:00:00Z", value = 23 },
                            new { koko = "2025-01-01T16:00:00Z", value = 18 },
                            new { koko = "2025-01-01T17:00:00Z", value = 17 },
                            new { koko = "2025-01-01T18:00:00Z", value = 23 },
                            new { koko = "2025-01-01T19:00:00Z", value = 18 },
                            new { koko = "2025-01-01T20:00:00Z", value = 11 },
                            new { koko = "2025-01-01T21:00:00Z", value = 20 },
                            new { koko = "2025-01-01T22:00:00Z", value = 20 },
                            new { koko = "2025-01-01T23:00:00Z", value = 12 },
                            new { koko = "2025-01-02T00:00:00Z", value = 10 },
                            new { koko = "2025-01-02T01:00:00Z", value = 25 },
                            new { koko = "2025-01-02T02:00:00Z", value = 17 },
                            new { koko = "2025-01-02T03:00:00Z", value = 15 },
                            new { koko = "2025-01-02T04:00:00Z", value = 18 },
                            new { koko = "2025-01-02T05:00:00Z", value = 25 },
                            new { koko = "2025-01-02T06:00:00Z", value = 18 },
                            new { koko = "2025-01-02T07:00:00Z", value = 25 },
                            new { koko = "2025-01-02T08:00:00Z", value = 9 },
                            new { koko = "2025-01-02T09:00:00Z", value = 20 },
                            new { koko = "2025-01-02T10:00:00Z", value = 23 },
                            new { koko = "2025-01-02T11:00:00Z", value = 22 },
                            new { koko = "2025-01-02T12:00:00Z", value = 21 },
                            new { koko = "2025-01-02T13:00:00Z", value = 14 },
                            new { koko = "2025-01-02T14:00:00Z", value = 19 },
                            new { koko = "2025-01-02T15:00:00Z", value = 10 },
                            new { koko = "2025-01-02T16:00:00Z", value = 23 },
                            new { koko = "2025-01-02T17:00:00Z", value = 21 },
                            new { koko = "2025-01-02T18:00:00Z", value = 20 },
                            new { koko = "2025-01-02T19:00:00Z", value = 14 },
                            new { koko = "2025-01-02T20:00:00Z", value = 17 },
                            new { koko = "2025-01-02T21:00:00Z", value = 19 },
                            new { koko = "2025-01-02T22:00:00Z", value = 20 },
                            new { koko = "2025-01-02T23:00:00Z", value = 17 },
                            new { koko = "2025-01-03T00:00:00Z", value = 16 },
                            new { koko = "2025-01-03T01:00:00Z", value = 11 },
                            new { koko = "2025-01-03T02:00:00Z", value = 9 },
                            new { koko = "2025-01-03T03:00:00Z", value = 8 },
                            new { koko = "2025-01-03T04:00:00Z", value = 11 },
                            new { koko = "2025-01-03T05:00:00Z", value = 16 },
                            new { koko = "2025-01-03T06:00:00Z", value = 23 },
                            new { koko = "2025-01-03T07:00:00Z", value = 23 },
                            new { koko = "2025-01-03T08:00:00Z", value = 8 },
                            new { koko = "2025-01-03T09:00:00Z", value = 21 },
                            new { koko = "2025-01-03T10:00:00Z", value = 11 },
                            new { koko = "2025-01-03T11:00:00Z", value = 15 },
                            new { koko = "2025-01-03T12:00:00Z", value = 20 },
                            new { koko = "2025-01-03T13:00:00Z", value = 19 },
                            new { koko = "2025-01-03T14:00:00Z", value = 24 }
                        }
                    },
                    new
                    {
                        label = "Vlhkost",
                        borderColor = "rgba(54, 162, 235, 1)", // Modrá barva
                        data = new[]
                        {
                            new { koko = "2025-01-01T10:00:00Z", value = 30 },
                            new { koko = "2025-01-01T11:00:00Z", value = 25 },
                            new { koko = "2025-01-01T12:15:00Z", value = 20 },
                            new { koko = "2025-01-01T12:30:00Z", value = 35 },
                            new { koko = "2025-01-01T14:00:00Z", value = 37 }
                        }
                    }
                }
            });

            // Pass raw JSON to the view
            ViewBag.TimeUnit = "hour";
            ViewBag.Minimum = 10-5;
            ViewBag.Maximum = 40+5;
            return View();
        }
    }
}
