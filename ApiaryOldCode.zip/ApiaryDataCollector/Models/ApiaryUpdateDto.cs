﻿namespace ApiaryDataCollector.Models
{
    public class ApiaryUpdateDto
    {
        public string? Name { get; set; }
        // Další vlastnosti, které chceš povolit při aktualizaci včelína
    }
}
