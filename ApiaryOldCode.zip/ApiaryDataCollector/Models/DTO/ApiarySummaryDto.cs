﻿namespace ApiaryDataCollector.Models.DTO
{
    public class ApiarySummaryDto
    {
        public int ApiaryNumber { get; set; }
        public string? Name { get; set; }
    }
}
