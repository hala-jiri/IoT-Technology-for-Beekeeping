﻿namespace ApiaryDataCollector.Models.DTO
{
    public class HiveUpdateDto
    {
        public string? Name { get; set; }
        // Přidej další vlastnosti, pokud jsou potřeba
    }
}