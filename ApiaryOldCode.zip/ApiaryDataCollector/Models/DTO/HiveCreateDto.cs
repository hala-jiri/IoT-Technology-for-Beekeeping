﻿namespace ApiaryDataCollector.Models.DTO
{
    public class HiveCreateDto
    {
        public string? Name { get; set; }
        public int ApiaryNumber { get; set; }
        // Přidej další vlastnosti, pokud jsou potřeba
    }
}
