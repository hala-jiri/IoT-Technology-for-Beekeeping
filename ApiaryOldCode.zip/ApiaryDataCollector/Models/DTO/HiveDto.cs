﻿namespace ApiaryDataCollector.Models.DTO
{
    public class HiveDto
    {
        public int HiveNumber { get; set; }
        public double Weight { get; set; }
        public double Temperature { get; set; }
        public int Humidity { get; set; }
    }
}
