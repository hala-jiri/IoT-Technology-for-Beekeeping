﻿namespace ApiaryDataCollector.Models.DTO
{
    public class ApiaryCreateDto
    {
        public required string Name { get; set; }
        // Další vlastnosti, které chceš povolit při vytváření včelína
    }
}
